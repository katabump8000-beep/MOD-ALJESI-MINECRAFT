package com.jes.customgameplay.registry;

import com.jes.customgameplay.CustomGameplayMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, CustomGameplayMod.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CustomGameplayMod.MODID);

    public static final List<RegistryObject<Block>> ROCKS = new ArrayList<>();

    static {
        String[] names = {
            "granite_pebbles", "mossy_pebbles", "limestone_pebbles", "slate_pebbles",
            "dark_rock_cluster", "light_rock_cluster", "mossy_rock", "lichen_rock",
            "river_stones", "chalk_stones", "basalt_fragments", "sandstone_fragments",
            "weathered_stone", "cracked_stone", "red_stone_pebbles", "gray_shale",
            "brown_shale", "cave_rocks", "small_mossy_boulder", "smooth_river_rock"
        };
        for (String name : names) {
            RegistryObject<Block> block = registerBlock(name, () -> new Block(
                    BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
                            .strength(0.7F).sound(SoundType.STONE).noOcclusion()));
            ROCKS.add(block);
        }
    }

    private static RegistryObject<Block> registerBlock(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    private ModBlocks() {}
}
