package com.jes.customgameplay.registry;

import com.jes.customgameplay.CustomGameplayMod;
import com.jes.customgameplay.entity.BanditEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CustomGameplayMod.MODID);

    public static final RegistryObject<EntityType<BanditEntity>> BANDIT = ENTITY_TYPES.register("bandit",
            () -> EntityType.Builder.of(BanditEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(12).build("bandit"));

    private ModEntities() {}
}
