package com.jes.customgameplay.registry;

import com.jes.customgameplay.CustomGameplayMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, CustomGameplayMod.MODID);

    public static final RegistryObject<SoundEvent> DIAMOND_FOUND = sound("diamond_found");
    public static final RegistryObject<SoundEvent> NETHERITE_FOUND = sound("netherite_found");
    public static final RegistryObject<SoundEvent> IRON_FOUND = sound("iron_found");
    public static final RegistryObject<SoundEvent> GOLD_FOUND = sound("gold_found");
    public static final RegistryObject<SoundEvent> NETHER_ENTERED = sound("nether_entered");

    private static RegistryObject<SoundEvent> sound(String name) {
        ResourceLocation id = new ResourceLocation(CustomGameplayMod.MODID, name);
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
    private ModSounds() {}
}
