package com.jes.customgameplay.event;

import com.jes.customgameplay.CustomGameplayMod;
import com.jes.customgameplay.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.entity.EntityTravelToDimensionEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CustomGameplayMod.MODID)
public final class GameplayEvents {
    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        Level level = (Level) event.getLevel();
        BlockPos pos = event.getPos();
        var block = event.getState().getBlock();

        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
            announce(player, level, pos, ModSounds.DIAMOND_FOUND.get(), "حصل على الدايموند!");
        } else if (block == Blocks.ANCIENT_DEBRIS) {
            announce(player, level, pos, ModSounds.NETHERITE_FOUND.get(), "حصل على النذررايت!");
        } else if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
            if (!player.getPersistentData().getBoolean("customgameplay_has_mined_iron")) {
                player.getPersistentData().putBoolean("customgameplay_has_mined_iron", true);
                announce(player, level, pos, ModSounds.IRON_FOUND.get(), "عثر على الحديد لأول مرة!");
            }
        } else if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) {
            if (!player.getPersistentData().getBoolean("customgameplay_has_mined_gold")) {
                player.getPersistentData().putBoolean("customgameplay_has_mined_gold", true);
                announce(player, level, pos, ModSounds.GOLD_FOUND.get(), "عثر على الذهب لأول مرة!");
            }
        }
    }

    @SubscribeEvent
    public static void onDimensionTravel(EntityTravelToDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getDimension() != Level.NETHER || player.level().dimension() == Level.NETHER) return;
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.blockPosition(), ModSounds.NETHER_ENTERED.get(),
                SoundSource.PLAYERS, 1.0F, 1.0F);
        player.server.getPlayerList().broadcastSystemMessage(
                Component.literal("§6" + player.getGameProfile().getName() + " دخل عالم النذر!"), false);
    }

    private static void announce(ServerPlayer player, Level level, BlockPos pos,
                                 net.minecraft.sounds.SoundEvent sound, String message) {
        level.playSound(null, pos, sound, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.server.getPlayerList().broadcastSystemMessage(
                Component.literal("§b" + player.getGameProfile().getName() + " " + message), false);
    }
    private GameplayEvents() {}
}
