package com.jes.customgameplay;

import com.jes.customgameplay.registry.ModBlocks;
import com.jes.customgameplay.registry.ModEntities;
import com.jes.customgameplay.registry.ModSounds;
import com.jes.customgameplay.world.RockWorldGen;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CustomGameplayMod.MODID)
public class CustomGameplayMod {
    public static final String MODID = "customgameplay";

    public CustomGameplayMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlocks.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
        RockWorldGen.register(bus);
    }
}
