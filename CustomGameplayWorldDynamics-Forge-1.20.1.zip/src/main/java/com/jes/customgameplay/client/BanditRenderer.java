package com.jes.customgameplay.client;

import com.jes.customgameplay.CustomGameplayMod;
import com.jes.customgameplay.entity.BanditEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class BanditRenderer extends HumanoidMobRenderer<BanditEntity, HumanoidModel<BanditEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(CustomGameplayMod.MODID, "textures/entity/bandit.png");

    public BanditRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BanditEntity entity) {
        return TEXTURE;
    }
}
