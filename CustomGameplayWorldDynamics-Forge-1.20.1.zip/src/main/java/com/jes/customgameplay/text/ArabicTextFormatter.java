package com.jes.customgameplay.text;

/**
 * Minecraft Java 1.20.1 uses font rendering with bidirectional text support in many contexts.
 * Do not reverse the entire Arabic string here: that commonly breaks mixed Arabic/Latin text.
 * This helper preserves text safely; test with the exact chat/font configuration in use.
 * Full Arabic shaping requires a bidi/shaping library and client-side integration.
 */
public final class ArabicTextFormatter {
    public static String format(String text) {
        return text == null ? "" : text;
    }
    private ArabicTextFormatter() {}
}
