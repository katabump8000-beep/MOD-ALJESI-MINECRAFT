WORLDGEN / STRUCTURE STATUS
The 20 rock blocks and models are registered. This starter project does not yet include complete configured/placed feature codecs,
biome modifiers, custom noise settings, or Structure NBT templates. These cannot be made into functioning generated huts/forts merely
by adding a JSON filename: each structure needs valid templates or a custom Structure/StructurePiece implementation.
Use Minecraft's structure block to export .nbt templates into:
  data/customgameplay/structures/
Then register template pools/structure sets or implement custom structures.
